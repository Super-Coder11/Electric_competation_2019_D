#ifndef __AD9833_H__
#define __AD9833_H__

#include "main.h"
#define SIN 0
#define Single 01
#define Squre 10

void AD9833_GPIOinit(void);

void AD9833_Write(unsigned short TxData);

void AD9833_CtrlSet(unsigned char Reset,unsigned char SleeppMode,unsigned char optionbit,unsigned char modebit);

void AD9833_FreqSet(uint32_t Freq);

void AD9833_Reset();

void AD9833_Start(uint32_t Freq,uint8_t Mode);

#endif